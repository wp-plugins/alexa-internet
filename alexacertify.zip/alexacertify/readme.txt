=== Plugin Name ===
Contributors: alexainternet,wcoburn
Tags: alexa, analytics
Requires at least: 3.0
Tested up to: 3.4.1
Stable tag: trunk
License: GPLv2 or later

This plugin allows you to easily claim and ceritfy your Wordpress blog on Alexa.com.

== Description ==

The Official Alexa Wordpress Plugin makes it easy to claim your Wordpress site on Alexa.com. Once you have claimed your site, you can edit your Alexa.com site listing.

If you have an Alexa Pro subscription for your Wordpress site, this plugin makes it easy to add the Certify Code. To learn more about Certification and Alexa Pro, visit http://www.alexa.com/prodcuts

== Installation ==

To claim your site:
1. Upload the Official Alexa Wordpress Plugin to your site.
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Visit http://www.alexa.com/siteowners/claim and follow the instructions
1. Enter your Alexa verification ID into the plugin and Update
1. Click "Verify my ID" on Alexa.com

To certify your site:
1. Upload the Official Alexa Wordpress Plugin to your site.
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Visit http://www.alexa.com/pro/dashboard and follow the instructions


== Changelog ==

= 1.0 =
